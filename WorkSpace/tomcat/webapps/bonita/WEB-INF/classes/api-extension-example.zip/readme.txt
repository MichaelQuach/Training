is is a REST API extension example archive for Bonita BPM Portal.

You can customize this custom page by modifying the existing resources or by adding or removing some.

Examples provided in the archive:

Customize response with additional header, cookie and response code
Get resource return a simple echo of query parameters
Use a provided logger
Post resources with Json payload and return a simple echo of parameters
Return an XML content with specific media type and character set

Content detail:

Index.groovy      Customize response with additional header, cookie and response code
Get.groovy        Get resource return a simple echo of query parameters
Log.groovy        Use a provided logger
Post.groovy       Post resources with Json payload and return a simple echo of parameters
Xml.groovy        Return an XML content with specific media type and character set
Soap.groovy       Call to external SOAP webservice (requires internet connexion)
xml/demo.xmlxml   sample file used by Xml.groovy example
page.properties   Contains page metadata (such as name, displayName, description, extension configuration), and is used by the Engine when the platform starts and when a extension is added or updated
readme.txt        this file
